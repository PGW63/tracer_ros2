from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    bringup_dir = FindPackageShare('nav2_bringup')
    tracer_nav_dir = FindPackageShare('tracer_navigation')

    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([bringup_dir, 'launch', 'bringup_launch.py'])
            ]),
            launch_arguments={
                'slam': 'true',
                'use_sim_time': 'true',
                'params_file': PathJoinSubstitution([tracer_nav_dir, 'params', 'nav2_params.yaml'])
            }.items()
        )
    ])

